/** @type {import('next').NextConfig} */

const nextConfig = {
  useFileSystemPublicRoutes: false,
  reactStrictMode: true,
  swcMinify: true,
  env: {
    NEXT_PUBLIC_API: process.env.NEXT_PUBLIC_API,
  },
}

module.exports = nextConfig
