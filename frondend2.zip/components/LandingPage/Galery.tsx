// import React from 'react'

// export const Galery = () => {
//   return (
//     <div className="galery flex mx-24 justify-between items-center ">
//         <img
//           src="/img/gambar1.svg"
//           alt="Logo"
//           width={248}
//           height={466}
//           className="mr-3"
//         />
//         <div className="justify-center m-8">
//           <div className="flex justify-center">
//           <img
//               src="/img/gambar2.svg"
//               alt="Logo"
//               width={280}
//               height={233}
//               className='mr-10'
//             />
//             <img
//               src="/img/gambar3.svg"
//               alt="Logo"
//               width={280}
//               height={233}
              
//             />
//           </div>
//           <img
//             src="/img/gambar4.svg"
//             alt="Logo"
//             width={639}
//             height={325}
//             className='mt-10'
//           />
//         </div>
//         <img
//           src="/img/gambar5.svg"
//           alt="Logo"
//           width={248}
//           height={466}
//           className="ml-[1rem]"
//         />
//       </div>
//   )
// }
// export default Galery